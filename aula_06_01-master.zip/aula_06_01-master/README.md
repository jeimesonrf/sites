# aula de 01 / 06 e 02 / 06

Turma 2ºD e 2ºC

Utilizar os conceitos de HTML e CSS
Colocar em prática os conceitos de flexbox
